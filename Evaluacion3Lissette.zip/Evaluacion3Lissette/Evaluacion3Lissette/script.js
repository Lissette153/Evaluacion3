function validar() {
    var correo = validar_correo();
    var contraseña = validar_contraseña();
    var confirmar = validar_confirmar();
    var telefono = validar_telefono();
    var direccion = validar_direccion();
    var pagina = validar_pagina();
    var aficion = validar_lista();
    var ret_check= validar_check();
    return correo && contraseña && confirmar && telefono && direccion && pagina && aficion && ret_check;
}

function enviar() {
    if (validar()) {
    
    }
}


function validar_check() {
    var check = document.getElementById("acepto");
    var div = document.getElementById("err_acepto");
    if (!check.checked) {
        div.innerText = "Debe aceptar las condiciones";
        div.className = "text-danger";
        return false;
    } else {
        div.innerText = "";
        return true;
    }
}



function validar_correo() {
    var correo = document.getElementById("correo").value;
    var div = document.getElementById("correo_usur");

    if (correoV(correo)) {
        div.innerText = "";
        return true;
   
    } else if (correo == "") {
        div.innerText= "Debes ingresar un correo como nombre de usuario";
        div.className= "text-danger";
     
    } else {
        div.innerText = "El correo electrónico no es correcto";
        div.className = "text-danger";
        return false;
    }
}

function correoV(correo) {
    var atPos = correo.indexOf("@");
    var dotPos = correo.indexOf(".");

    if (atPos < 1 || dotPos < atPos + 2 || dotPos + 2 >= correo.length) {
        return false;
    }

    return true;
}

function validar_contraseña() {
    var contraseña = document.getElementById("contraseña").value;
    var div = document.getElementById("contra_ur");

    if (contraseña.length >= 3 && contraseña.length <= 6) {
        div.innerText = "";
        return true;

    } else if(contraseña == ""){
        div.innerText= "Debes ingresar una contraseña";
        div.className= "text-danger";
        return false;

    } else {
        div.innerText = "La contraseña debe tener entre 3 y 6 caracteres";
        div.className = "text-danger";
        return false;
    }
}

function validar_confirmar() {
    var contraseña = document.getElementById("contraseña").value;
    var confirmar = document.getElementById("confirm").value;
    var div = document.getElementById("confir_contr");

    if (confirmar.length >= 3 && confirmar.length <= 6 && confirmar === contraseña) {
        div.innerText = "";
        return true;
    
    }else if (confirmar == "") {
        div.innerText= "Debes ingresar la confirmacion de la contraseña";
        div.className= "text-danger";
        return false;
    
    } else {
        div.innerText = "La confirmación de la contraseña debe coincidir con la contraseña y tener entre 3 y 6 caracteres";
        div.className = "text-danger";
        return false;
    }
}


function validar_telefono() {
    var telefono = document.getElementById("telefono").value;
    var div = document.getElementById("tel_ur");

    if (telefono.length === 9 ||  telefono.startsWith("+569")) {
        div.innerText = "";
        return true;
    } else if (telefono === ""){
        div.innerText= "Debes ingresar un numero telefonico";
        div.className= "text-danger";
        return false;

    
    } else {
        div.innerText = "El número telefónico debe tener 9 numeros y empezar con +569 en caso de ser chileno";
        div.className = "text-danger";
        return false;
    }
}

function validar_pagina() {
    var pagina = document.getElementById("pagina").value;
    var div = document.getElementById("pag_url"); 

    if (pagina == "") {
        div.innerText = "Debes ingresar una URL de su página web";
        div.className = "text-danger";
        return false;
    }
    
      var httpIndex = pagina.indexOf("http://");
      var httpsIndex = pagina.indexOf("https://");
      var wwwIndex= pagina.indexOf("www.");
    
      if (httpIndex === 0 || httpsIndex === 0 || wwwIndex === 0) {
        div.innerText = "";
        return true;
      } else {
        div.innerText = "La URL de la página web no es correcta";
        div.className = "text-danger";
        return false;
      }
}
    

function validar_lista(event) {

    var input = document.getElementById("aficion");
    var valor = input.value.trim();
    var div = document.getElementById("list_aficion");


    if (valor !== "") {
        var lista = document.getElementById("aficion-lista");
        var listaAficiones = lista.getElementsByTagName("li");


        if (listaAficiones.length >= 2) {
            div.innerText = "Solo puedes ingresar 2 aficiones";
            div.className = "text-danger";
            return false;
        }


        var item = document.createElement("li");
        item.innerText = valor;
        lista.appendChild(item);


        input.value = "";
        div.innerText = "";

    } else {
        div.innerText = "Debes ingresar una afición";
        div.className = "text-danger";
        return false;
    }


    if (listaAficiones.length == 2) {
        div.innerText = "¡Aficiones ingresadas correctamente!";
        div.className = "text-success";
        console.log("Formulario validado con éxito"); 
        var successMessage = document.getElementById("success-message");
        successMessage.style.display = "block";
    }

    return true;
}


function validar_direccion(){
    var direccion= document.getElementById("direccion").value;
    var div= document.getElementById("calle_r");
    
    if (direccion == ""){
        div.innerText= "Debes ingresar una direccion o calle";
        div.className= "text-danger";
     
    }else{
        div.innerText="";
    }
}